# RunCplus — Desktop (Linux x86_64)

A live-feedback C/C++ editor built with Qt 6 and C++17. It compiles and runs
your code automatically a moment after you stop typing, with inline
diagnostics and a watchdog that kills runaway programs.

This package is **self-contained**: the Qt 6 runtime and its plugins ship
inside the bundle, so you do not need to install Qt.

## Requirements

- Linux x86_64 with glibc 2.34 or newer
- An X11 session (XWayland works) — the bundle includes the `xcb` platform plugin
- A system GCC toolchain (`g++`/`gcc`). The included `toolchain/bin` shims
  locate your system compiler automatically. Without GCC the editor still
  opens, but compilation is disabled.

## Run

```bash
tar -xzf RunCplus-Desktop-Linux-x86_64.tar.gz
cd RunCplus-Desktop-Linux-x86_64
./run-runcplus.sh
```

Use the launcher script, not the bare `RunCplus` binary — the script points
the loader at the bundled Qt libraries and plugins.

## Layout

| Path | Purpose |
| :--- | :--- |
| `run-runcplus.sh` | Launcher; sets `LD_LIBRARY_PATH`, `QT_PLUGIN_PATH`, `PATH` |
| `RunCplus` | The application binary |
| `lib/` | Bundled Qt 6.11.1 shared libraries |
| `plugins/` | Qt platform, image format, icon engine and xcb GL plugins |
| `toolchain/bin/` | `g++`/`gcc` shims that resolve your system compiler |

## Workspace

Playground files live in a per-user writable directory, created on first
launch:

```
~/.local/share/RunCplusLab/RunCplus/workspace
```

Compiled binaries are written to `/tmp/runcplus_binaries`.

## Runtime behaviour

- **Auto-run**: compiles ~500 ms after you stop typing (toggleable).
- **Watchdog**: execution is terminated after 2 seconds to catch infinite loops.
- **Cache**: binaries are cached by content hash, so an unchanged program re-runs
  without recompiling.
- **Standards**: C++17, C++20, C++23 and C11/C17.

## Troubleshooting

**`qt.qpa.plugin: Could not load the Qt platform plugin "xcb"`**
Make sure you launched via `./run-runcplus.sh`. If it persists, verify the
plugin's dependencies resolve:

```bash
LD_LIBRARY_PATH=./lib ldd plugins/platforms/libqxcb.so | grep "not found"
```

**`RunCplus: g++ not found on this system`**
Install GCC (`sudo dnf install gcc-c++` on Fedora).

**Blank window on Wayland without XWayland**
Run with `QT_QPA_PLATFORM=xcb` under XWayland, or install `xorg-x11-server-Xwayland`.
