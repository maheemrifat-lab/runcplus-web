#!/usr/bin/env bash
# RunCplus desktop launcher — sets up the bundled Qt runtime.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export LD_LIBRARY_PATH="$HERE/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export QT_PLUGIN_PATH="$HERE/plugins"
export QT_QPA_PLATFORM_PLUGIN_PATH="$HERE/plugins/platforms"
export PATH="$HERE/toolchain/bin:$PATH"

exec "$HERE/RunCplus" "$@"
